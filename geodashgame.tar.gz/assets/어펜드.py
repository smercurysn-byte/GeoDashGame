height=int(input(" "))
middle=height//2


for i in range(middle+1):
    spaces=" "*(middle-i)
    
    if i==0:
        stars="*"
    
    else:
        stars="*"+" "*(2*i-1)+"*"
        
    print(spaces+stars)


for i in range(middle-1,-1,-1):
    spaces=" "*(middle-i)
    
    if i==0:
        stars="*"
    else:
        stars="*"+" "*(2*i-1)+"*"
        
    print(spaces+stars)